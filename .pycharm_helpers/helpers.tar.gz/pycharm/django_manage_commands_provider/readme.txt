This helper fetchers manage commands from Django installation.
It supports custom commands as well.
Entry point is "_jb_manage_tasks_provider.py: one level up, it exports data in XML format that is described in "_xml.py".
This helper should be used in pair with com.intellij.python.django.RealCommandsProvider